INSERT INTO 
	TBL_BOOKS (BOOK_NAME, BOOK_AUTHOR, BOOK_PUBLISHER) 
VALUES
  	('Java', 'Joshua Bloch', 'Get book'),
  	('Java SE 8 for the Really Impatient', 'DCay S. Horstmannoe', 'Get book');